export class User {
  constructor(
    public street: string,
    public city: string,
    public state: string
  ) {
  }
}
